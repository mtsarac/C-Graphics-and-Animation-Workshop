#if _WIN32
#include <Windows.h>
#endif

#include <fstream>
#include <iostream>
#include <string>
#include <stdexcept>
#include <vector>

#define GLEW_STATIC
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include "wavefront.hpp"

float ar = 1.0f;

// Drawable Object
struct Object {
  GLuint program;
  GLuint vao;
  GLsizei count;
  GLuint tex_day;
  GLuint tex_night;
  GLuint tex_ocean;
  GLuint tex_clouds;
};

std::string readFile(const std::string& filename) {
  std::ifstream file(filename);

  if (!file.is_open()) {
    throw std::runtime_error("failed to open file!");
  }

  std::string content;
  content.assign(std::istreambuf_iterator<char>(file),
                 std::istreambuf_iterator<char>()
                );

  return content;
}

GLuint loadTexture(const std::string& filename) {
  int width, height, channels;
  unsigned char *data = stbi_load(filename.c_str(), &width, &height, &channels, 0);
  GLuint texture;
  glCreateTextures(GL_TEXTURE_2D, 1, &texture);
  glBindTexture(GL_TEXTURE_2D, texture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  GLenum format = GL_RGBA;
  if (channels == 3) format = GL_RGB;
  if (channels == 1) format = GL_RED;
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, format, GL_UNSIGNED_BYTE, data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, 0);
  stbi_image_free(data);
  return texture;
}

Object initObj() {
  Object obj {};

  // create and compile vertex shader
  const std::string vertexString = readFile("shader/shader.vert");
  const GLchar* vertexText = vertexString.c_str();
  GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
  glShaderSource(vertexShader, 1, &vertexText, nullptr);
  glCompileShader(vertexShader);
  GLint status;
  glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &status);
  if (!status) {
    GLchar infoLog[1024];
    glGetShaderInfoLog(vertexShader, 1024, nullptr, infoLog);
    #if _WIN32
    MessageBox( nullptr, TEXT( infoLog ), TEXT( "Error compiling vertex shader:" ), MB_OK );
    #else
    std::cout << "Error compiling vertex shader: " << infoLog << std::endl;
    #endif
  }

  // create and compile fragment shader
  const std::string fragmentString = readFile("shader/shader.frag");
  const GLchar* fragmentText = fragmentString.c_str();
  GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
  glShaderSource(fragmentShader, 1, &fragmentText, nullptr);
  glCompileShader(fragmentShader);
  glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &status);
  if (!status) {
    GLchar infoLog[1024];
    glGetShaderInfoLog(fragmentShader, 1024, nullptr, infoLog);
    #if _WIN32
    MessageBox( nullptr, TEXT( infoLog ), TEXT( "Error compiling fragment shader:" ), MB_OK );
    #else
    std::cout << "Error compiling fragment shader: " << infoLog << std::endl;
    #endif
  }

  // create and link shader program
  obj.program = glCreateProgram();
  glAttachShader(obj.program, vertexShader);
  glAttachShader(obj.program, fragmentShader);
  glLinkProgram(obj.program);
  glGetProgramiv(obj.program, GL_LINK_STATUS, &status);
  if (!status) {
    GLchar infoLog[1024];
    glGetProgramInfoLog(obj.program, 1024, nullptr, infoLog);
    #if _WIN32
    MessageBox( nullptr, TEXT( infoLog ), TEXT( "Error linking program:" ), MB_OK );
    #else
    std::cout << "Error linking program: " << infoLog << std::endl;
    #endif
  }
  glValidateProgram(obj.program);
  glGetProgramiv(obj.program, GL_VALIDATE_STATUS, &status);
  if (!status) {
    GLchar infoLog[1024];
    glGetProgramInfoLog(obj.program, 1024, nullptr, infoLog);
    #if _WIN32
    MessageBox( nullptr, TEXT( infoLog ), TEXT( "Error validating program:" ), MB_OK );
    #else
    std::cout << "Error validating program: " << infoLog << std::endl;
    #endif
  }
  
  std::vector<wavefront::Vertex> vertices;
  wavefront::load("earth.obj", vertices);
  obj.count = vertices.size();

  // create vertex buffer object
  GLuint vbo;
  glGenBuffers(1, &vbo);
  glBindBuffer(GL_ARRAY_BUFFER, vbo);
  glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(wavefront::Vertex), vertices.data(), GL_STATIC_DRAW);
  glBindBuffer(GL_ARRAY_BUFFER, 0);

  // create vertex array object
  glGenVertexArrays(1, &(obj.vao));
  glBindVertexArray(obj.vao);
  glBindBuffer(GL_ARRAY_BUFFER, vbo);
  glVertexAttribPointer(
    0,
    3,
    GL_FLOAT,
    GL_FALSE,
    sizeof(wavefront::Vertex),
    offsetof(wavefront::Vertex, pos)
  );
  glEnableVertexAttribArray(0);
  glVertexAttribPointer(
    1,
    2,
    GL_FLOAT,
    GL_FALSE,
    sizeof(wavefront::Vertex),
    (const void*)offsetof(wavefront::Vertex, tex)
  );
  glEnableVertexAttribArray(1);
  glVertexAttribPointer(
    2,
    3,
    GL_FLOAT,
    GL_FALSE,
    sizeof(wavefront::Vertex),
    (const void*)offsetof(wavefront::Vertex, nor)
  );
  glEnableVertexAttribArray(2);
  glBindBuffer(GL_ARRAY_BUFFER, 0);
  glBindVertexArray(0);

  obj.tex_day = loadTexture("texture/earth_day.png");
  obj.tex_night = loadTexture("texture/earth_night.png");
  obj.tex_ocean = loadTexture("texture/earth_ocean_mask.png");
  obj.tex_clouds = loadTexture("texture/earth_clouds.png");

  return obj;
}

void draw(Object obj) {
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glUseProgram(obj.program);
  
  double time = glfwGetTime() * 0.5;

  GLint modelLocation = glGetUniformLocation(obj.program, "uModel");
  glm::mat4 model = glm::rotate(glm::mat4(1.0f), (float)time, glm::vec3(0.0f, 1.0f, 0.0f));
  glUniformMatrix4fv(modelLocation, 1, GL_FALSE, &model[0][0]);
  
  GLint viewLocation = glGetUniformLocation(obj.program, "uView");
  glm::mat4 view = glm::lookAt(glm::vec3(0.0f, 0.0f, -5.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
  glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

  GLint projLocation = glGetUniformLocation(obj.program, "uProj");
  glm::mat4 proj = glm::perspective(glm::radians(45.0f), ar, 0.1f, 100.0f);
  glUniformMatrix4fv(projLocation, 1, GL_FALSE, &proj[0][0]);
  
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, obj.tex_day);
  glUniform1i(glGetUniformLocation(obj.program, "uTexDay"), 0);

  glActiveTexture(GL_TEXTURE1);
  glBindTexture(GL_TEXTURE_2D, obj.tex_night);
  glUniform1i(glGetUniformLocation(obj.program, "uTexNight"), 1);

  glActiveTexture(GL_TEXTURE2);
  glBindTexture(GL_TEXTURE_2D, obj.tex_ocean);
  glUniform1i(glGetUniformLocation(obj.program, "uTexOcean"), 2);

  glActiveTexture(GL_TEXTURE3);
  glBindTexture(GL_TEXTURE_2D, obj.tex_clouds);
  glUniform1i(glGetUniformLocation(obj.program, "uTexClouds"), 3);

  glUniform1f(glGetUniformLocation(obj.program, "uShift"), (float)time/30.0f);
  
  glBindVertexArray(obj.vao);

  glDrawArrays(GL_TRIANGLES, 0, obj.count);
}

void framebuffer_size_callback(GLFWwindow* /*window*/, int width, int height) {
  glViewport(0, 0, width, height);
  ar = (float)width/height;
}

int main() {
  glfwInit();
  glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
  glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
  glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

  GLFWwindow* window = glfwCreateWindow(600, 600, "Earth", nullptr, nullptr);
  if (!window) {
    std::cout << "Failed to create window" << std::endl;
    glfwTerminate();
    return -1;
  }
  glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
  glfwMakeContextCurrent(window);
  glewInit();

  Object obj = initObj();
  glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
  glViewport(0, 0, 600, 600);
  glEnable(GL_DEPTH_TEST);

  while (!glfwWindowShouldClose(window)) {
    draw(obj);
    glfwSwapBuffers(window);
    glfwPollEvents();
  }

  glfwTerminate();
  return 0;
}

